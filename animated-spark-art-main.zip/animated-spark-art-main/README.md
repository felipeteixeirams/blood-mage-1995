# Blood Mage 1995

Quero transformar essa imgem em código react + phaser para meu jogo que estou criando em PWA, eu gostaria dele animado, com o fundo espiral rotacionando lentamente e as os fogo das tochas movimentando aleatoriamente e a iluminação compatível com o movimento do fogo, tudo isso para não usar essa imagem diretamente como fundo do meu jogo e deixar tudo mais refinado e ajustavel a resolução da tela do aparelho, fique a vontade para usar de recursos próprios ou importar sprites ou qualquer outros elementos externos para a máxima fidelidade.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/aa322991-8f75-486c-9e8c-6d3ca3470e22).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
