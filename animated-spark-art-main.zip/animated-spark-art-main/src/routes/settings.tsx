import { createFileRoute, ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense } from "react";

const BloodmageSettings = lazy(() =>
  import("@/components/BloodmageSettings").then((m) => ({ default: m.BloodmageSettings })),
);

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Bloodmage 1995 — Configurações" },
      {
        name: "description",
        content:
          "Menu de configurações 16-bit de Bloodmage 1995: sliders de áudio, brilho e contraste, scanlines CRT e opções de jogo em React + Phaser.",
      },
      { property: "og:title", content: "Bloodmage 1995 — Configurações" },
      {
        property: "og:description",
        content:
          "Ajuste áudio, brilho, contraste e efeitos retrô no menu gótico animado de Bloodmage 1995.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <main className="flex h-[100dvh] w-full items-center justify-center overflow-hidden bg-[#07080b]">
      <h1 className="sr-only">Bloodmage 1995 — Configurações</h1>
      <ClientOnly fallback={<div className="text-sm text-[#7a6a52]">Invocando…</div>}>
        <Suspense fallback={<div className="text-sm text-[#7a6a52]">Invocando…</div>}>
          <BloodmageSettings />
        </Suspense>
      </ClientOnly>
    </main>
  );
}
