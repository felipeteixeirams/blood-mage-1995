import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense } from "react";

const BloodmageTitle = lazy(() =>
  import("@/components/BloodmageTitle").then((m) => ({ default: m.BloodmageTitle })),
);

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bloodmage 1995 — Tela de Título" },
      {
        name: "description",
        content:
          "Tela de título animada em 16-bit de Bloodmage 1995: vórtice arcano girando, tochas com fogo vivo e iluminação dinâmica, feita em React + Phaser.",
      },
      { property: "og:title", content: "Bloodmage 1995 — Tela de Título" },
      {
        property: "og:description",
        content:
          "Vórtice arcano em rotação, tochas flamejantes e iluminação reativa numa tela de título retrô 16-bit.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="flex h-[100dvh] w-full items-center justify-center overflow-hidden bg-[#0b0a09]">
      <h1 className="sr-only">Bloodmage 1995</h1>
      <ClientOnly fallback={<div className="text-sm text-[#7a6a52]">Invocando…</div>}>
        <Suspense fallback={<div className="text-sm text-[#7a6a52]">Invocando…</div>}>
          <BloodmageTitle />
        </Suspense>
      </ClientOnly>
    </main>
  );
}
