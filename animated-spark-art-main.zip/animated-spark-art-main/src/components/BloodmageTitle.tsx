import { useEffect, useRef } from "react";
import { useNavigate } from "@tanstack/react-router";

/**
 * Mounts the Phaser title screen. Phaser is imported dynamically so it never
 * runs during SSR, and the canvas scales to any device resolution.
 */
export function BloodmageTitle() {
  const holder = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    let destroyed = false;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let game: any = null;

    (async () => {
      const [{ default: Phaser }, { TitleScene, BASE_W, BASE_H }] = await Promise.all([
        import("phaser"),
        import("@/game/TitleScene"),
      ]);
      if (destroyed || !holder.current) return;

      game = new Phaser.Game({
        type: Phaser.AUTO,
        parent: holder.current,
        width: BASE_W,
        height: BASE_H,
        backgroundColor: "#0b0a09",
        pixelArt: true,
        roundPixels: true,
        scale: {
          mode: Phaser.Scale.FIT,
          autoCenter: Phaser.Scale.CENTER_BOTH,
        },
        scene: [TitleScene],
      });
      game.registry.set("navigate", (to: string) => navigate({ to }));
    })();

    return () => {
      destroyed = true;
      game?.destroy(true);
    };
  }, [navigate]);

  return (
    <div
      ref={holder}
      className="h-full w-full [&_canvas]:!h-auto [&_canvas]:!w-auto [&_canvas]:max-h-full [&_canvas]:max-w-full"
      aria-label="Tela de título animada de Bloodmage 1995"
      role="img"
    />
  );
}

export default BloodmageTitle;