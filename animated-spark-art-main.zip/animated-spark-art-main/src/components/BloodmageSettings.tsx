import { useEffect, useRef } from "react";
import { useNavigate } from "@tanstack/react-router";

/**
 * Mounts the Phaser settings screen. Phaser loads dynamically (never in SSR)
 * and the canvas scales to any device resolution.
 */
export function BloodmageSettings() {
  const holder = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    let destroyed = false;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let game: any = null;

    (async () => {
      const [{ default: Phaser }, { SettingsScene, BASE_W, BASE_H }] = await Promise.all([
        import("phaser"),
        import("@/game/SettingsScene"),
      ]);
      if (destroyed || !holder.current) return;

      game = new Phaser.Game({
        type: Phaser.AUTO,
        parent: holder.current,
        width: BASE_W,
        height: BASE_H,
        backgroundColor: "#07080b",
        pixelArt: true,
        roundPixels: true,
        scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
        scene: [SettingsScene],
      });
      game.registry.set("navigate", (to: string) => navigate({ to }));
    })();

    return () => {
      destroyed = true;
      game?.destroy(true);
    };
  }, [navigate]);

  return (
    <div
      ref={holder}
      className="h-full w-full [&_canvas]:!h-auto [&_canvas]:!w-auto [&_canvas]:max-h-full [&_canvas]:max-w-full"
      aria-label="Tela de configurações de Bloodmage 1995"
      role="application"
    />
  );
}

export default BloodmageSettings;
