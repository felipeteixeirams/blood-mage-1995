import Phaser from "phaser";
import {
  createEmberTexture,
  createGlowTexture,
  createScanlineTexture,
} from "./textures";

import rockTileUrl from "@/assets/rock-tile.jpg";
import stoneTileUrl from "@/assets/stone-tile.jpg";
import cornerUrl from "@/assets/ui-corner.png";
import plaqueUrl from "@/assets/ui-plaque.png";
import gemUrl from "@/assets/ui-gem.png";
import capUrl from "@/assets/ui-slider-cap.png";

export const BASE_W = 960;
export const BASE_H = 540;

const STORE_KEY = "bloodmage.settings";

type SettingsState = {
  volume: number;
  music: number;
  brightness: number;
  contrast: number;
  scanlines: boolean;
  shake: boolean;
  blood: boolean;
};

const DEFAULTS: SettingsState = {
  volume: 0.8,
  music: 0.6,
  brightness: 0.5,
  contrast: 0.5,
  scanlines: true,
  shake: true,
  blood: true,
};

function loadState(): SettingsState {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) return { ...DEFAULTS, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { ...DEFAULTS };
}

/** Deterministic pseudo-noise in [-1, 1] — the heartbeat of every flame. */
function flicker(t: number, seed: number) {
  return (
    0.55 * Math.sin(t * 6.9 + seed) +
    0.28 * Math.sin(t * 14.3 + seed * 2.13) +
    0.17 * Math.sin(t * 27.7 + seed * 3.71)
  );
}

type Slider = {
  key: keyof SettingsState;
  x: number;
  y: number;
  w: number;
  fill: Phaser.GameObjects.Graphics;
  gem: Phaser.GameObjects.Image;
  glow: Phaser.GameObjects.Image;
  value: Phaser.GameObjects.Text;
};

type Toggle = {
  key: keyof SettingsState;
  gem: Phaser.GameObjects.Image;
  box: Phaser.GameObjects.Graphics;
  x: number;
  y: number;
};

export class SettingsScene extends Phaser.Scene {
  private t0 = 0;
  private state: SettingsState = { ...DEFAULTS };
  private saved: SettingsState = { ...DEFAULTS };
  private sliders: Slider[] = [];
  private toggles: Toggle[] = [];
  private dragging: Slider | null = null;
  private scan!: Phaser.GameObjects.TileSprite;
  private bright!: Phaser.GameObjects.Graphics;
  private contrast!: Phaser.GameObjects.Graphics;
  private plaqueGlow!: Phaser.GameObjects.Image;
  private logo!: Phaser.GameObjects.Text;
  private hint!: Phaser.GameObjects.Text;
  private lit: Phaser.GameObjects.Image[] = [];

  constructor() {
    super("settings");
  }

  preload() {
    this.load.image("rockTile", rockTileUrl);
    this.load.image("stoneTile", stoneTileUrl);
    this.load.image("uiCorner", cornerUrl);
    this.load.image("uiPlaque", plaqueUrl);
    this.load.image("uiGem", gemUrl);
    this.load.image("uiCap", capUrl);
  }

  create() {
    this.state = loadState();
    this.saved = { ...this.state };

    createScanlineTexture(this, "scanline");
    createEmberTexture(this, "ember", 16);
    createGlowTexture(this, "gemGlow", 256, "rgba(226,32,54,0.75)", "rgba(120,8,18,0.25)");
    createGlowTexture(this, "warmGlow", 512, "rgba(255,176,74,0.7)", "rgba(160,64,12,0.2)");
    createGlowTexture(this, "logoGlow", 512, "rgba(178,26,26,0.55)", "rgba(90,10,10,0.18)");

    this.buildBackdrop();
    this.buildFrame();
    this.buildHeader();
    this.buildSliders();
    this.buildToggles();
    this.buildButtons();
    this.buildOverlays();
    this.bindInput();
    this.applyLive();
  }

  /* --------------------------------------------------------------- layers */

  private buildBackdrop() {
    const rock = this.add.tileSprite(0, 0, BASE_W, BASE_H, "rockTile").setOrigin(0);
    rock.setTileScale(0.55).setTint(0x2a2c33).setDepth(0);

    const dark = this.add.graphics().setDepth(0);
    dark.fillStyle(0x05060a, 0.62).fillRect(0, 0, BASE_W, BASE_H);

    // faint arcane haze breathing behind the panel
    this.add
      .image(BASE_W / 2, BASE_H / 2, "warmGlow")
      .setDisplaySize(1100, 700)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setAlpha(0.06)
      .setDepth(0);
  }

  private buildFrame() {
    const g = this.add.graphics().setDepth(1);
    g.lineStyle(4, 0x11131a, 1).strokeRect(10, 10, BASE_W - 20, BASE_H - 20);
    g.lineStyle(2, 0x3d424f, 1).strokeRect(18, 18, BASE_W - 36, BASE_H - 36);

    const size = 210;
    const mk = (x: number, y: number, fx: boolean, fy: boolean) => {
      const img = this.add.image(x, y, "uiCorner").setOrigin(fx ? 1 : 0, fy ? 1 : 0);
      img.setDisplaySize(size, size).setFlipX(fx).setFlipY(fy).setDepth(2).setAlpha(0.95);
      this.lit.push(img);
      return img;
    };
    mk(14, 14, false, false);
    mk(BASE_W - 14, 14, true, false);
    mk(14, BASE_H - 14, false, true);
    mk(BASE_W - 14, BASE_H - 14, true, true);
  }

  private buildHeader() {
    const cx = BASE_W / 2;
    const plaque = this.add.image(cx, 64, "uiPlaque").setDisplaySize(700, 156).setDepth(3);
    this.lit.push(plaque);

    this.plaqueGlow = this.add
      .image(cx, 66, "logoGlow")
      .setDisplaySize(600, 190)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setAlpha(0.16)
      .setDepth(3);

    this.logo = this.add
      .text(cx, 62, "BLOODMAGE 1995", {
        fontFamily: "Georgia, 'Times New Roman', serif",
        fontSize: "52px",
        color: "#e8c76a",
        fontStyle: "bold",
      })
      .setOrigin(0.5)
      .setDepth(4)
      .setStroke("#2a1a06", 8)
      .setShadow(0, 4, "#000000", 4, true, true);
    this.logo.setLetterSpacing?.(3);

    this.add
      .text(cx, 124, "AJUSTES  E  CONFIGURA\u00c7\u00d5ES", {
        fontFamily: "monospace",
        fontSize: "14px",
        color: "#8f8a76",
        fontStyle: "bold",
      })
      .setOrigin(0.5)
      .setDepth(4);
  }

  /* -------------------------------------------------------------- sliders */

  private sliderDefs: { key: keyof SettingsState; label: string }[] = [
    { key: "volume", label: "VOLUME DE ÁUDIO" },
    { key: "music", label: "VOLUME DA MÚSICA" },
    { key: "brightness", label: "BRILHO DO VÍDEO" },
    { key: "contrast", label: "CONTRASTE DO VÍDEO" },
  ];

  private buildSliders() {
    const cx = BASE_W / 2;
    const w = 560;
    const startY = 172;
    const gap = 64;

    this.sliderDefs.forEach((def, i) => {
      const y = startY + i * gap;

      this.add
        .text(cx, y - 22, def.label, {
          fontFamily: "monospace",
          fontSize: "17px",
          color: "#e6d8ad",
          fontStyle: "bold",
        })
        .setOrigin(0.5)
        .setDepth(6)
        .setShadow(0, 2, "#000000", 2);

      // track
      const track = this.add.graphics().setDepth(5);
      track.fillStyle(0x0a0a0c, 1).fillRoundedRect(cx - w / 2, y + 2, w, 18, 4);
      track.lineStyle(2, 0xc9a227, 1).strokeRoundedRect(cx - w / 2, y + 2, w, 18, 4);

      const fill = this.add.graphics().setDepth(6);

      const capL = this.add.image(cx - w / 2 - 6, y + 11, "uiCap");
      capL.setDisplaySize(58, 58).setDepth(7);
      const capR = this.add.image(cx + w / 2 + 6, y + 11, "uiCap");
      capR.setDisplaySize(58, 58).setFlipX(true).setDepth(7);
      this.lit.push(capL, capR);

      const glow = this.add
        .image(cx, y + 11, "gemGlow")
        .setDisplaySize(120, 120)
        .setBlendMode(Phaser.BlendModes.ADD)
        .setAlpha(0.5)
        .setDepth(7);
      const gem = this.add.image(cx, y + 11, "uiGem").setDisplaySize(46, 46).setDepth(8);

      const value = this.add
        .text(cx + w / 2 + 44, y + 11, "", {
          fontFamily: "monospace",
          fontSize: "15px",
          color: "#c9a227",
          fontStyle: "bold",
        })
        .setOrigin(0, 0.5)
        .setDepth(8);

      const s: Slider = { key: def.key, x: cx, y: y + 11, w, fill, gem, glow, value };
      this.sliders.push(s);

      const hit = this.add
        .zone(cx, y + 11, w + 90, 52)
        .setOrigin(0.5)
        .setInteractive({ useHandCursor: true });
      hit.on("pointerdown", (p: Phaser.Input.Pointer) => {
        this.dragging = s;
        this.setFromPointer(s, p.worldX);
      });

      this.renderSlider(s);
    });
  }

  private setFromPointer(s: Slider, worldX: number) {
    const v = Phaser.Math.Clamp((worldX - (s.x - s.w / 2)) / s.w, 0, 1);
    (this.state[s.key] as number) = Math.round(v * 100) / 100;
    this.renderSlider(s);
    this.applyLive();
  }

  private renderSlider(s: Slider) {
    const v = this.state[s.key] as number;
    const left = s.x - s.w / 2;
    s.fill.clear();
    s.fill.fillStyle(0x7a1420, 1).fillRoundedRect(left + 2, s.y - 7, Math.max(2, s.w * v - 4), 14, 3);
    s.fill.fillStyle(0xc9282f, 0.75).fillRect(left + 3, s.y - 6, Math.max(1, s.w * v - 6), 4);
    s.gem.x = left + s.w * v;
    s.glow.x = s.gem.x;
    s.value.setText(`${Math.round(v * 100)}%`);
  }

  /* -------------------------------------------------------------- toggles */

  private toggleDefs: { key: keyof SettingsState; label: string }[] = [
    { key: "scanlines", label: "SCANLINES CRT" },
    { key: "shake", label: "TREMOR DE TELA" },
    { key: "blood", label: "SANGUE" },
  ];

  private buildToggles() {
    const y = 432;
    const spacing = 250;
    const startX = BASE_W / 2 - spacing;

    this.toggleDefs.forEach((def, i) => {
      const x = startX + i * spacing;
      const box = this.add.graphics().setDepth(6);
      const gem = this.add.image(x - 78, y, "uiGem").setDisplaySize(26, 26).setDepth(7);
      this.add
        .text(x - 58, y, def.label, {
          fontFamily: "monospace",
          fontSize: "14px",
          color: "#ccc0a0",
          fontStyle: "bold",
        })
        .setOrigin(0, 0.5)
        .setDepth(7);

      const t: Toggle = { key: def.key, gem, box, x, y };
      this.toggles.push(t);
      this.renderToggle(t);

      this.add
        .zone(x, y, 200, 40)
        .setOrigin(0.5)
        .setInteractive({ useHandCursor: true })
        .on("pointerdown", () => {
          (this.state[t.key] as boolean) = !(this.state[t.key] as boolean);
          this.renderToggle(t);
          this.applyLive();
        });
    });
  }

  private renderToggle(t: Toggle) {
    const on = this.state[t.key] as boolean;
    t.box.clear();
    t.box.fillStyle(0x0c0d11, 0.85).fillRoundedRect(t.x - 96, t.y - 17, 194, 34, 5);
    t.box.lineStyle(2, on ? 0xc9a227 : 0x4a4740, 1).strokeRoundedRect(t.x - 96, t.y - 17, 194, 34, 5);
    t.gem.setAlpha(on ? 1 : 0.28).setTint(on ? 0xffffff : 0x6a6a6a);
  }

  /* -------------------------------------------------------------- buttons */

  private buildButtons() {
    const y = 494;
    const defs: { label: string; run: () => void }[] = [
      {
        label: "APLICAR",
        run: () => {
          this.saved = { ...this.state };
          try {
            localStorage.setItem(STORE_KEY, JSON.stringify(this.state));
          } catch {
            /* ignore */
          }
          this.flash("CONFIGURAÇÕES SALVAS");
        },
      },
      {
        label: "RESTAURAR",
        run: () => {
          this.state = { ...DEFAULTS };
          this.sliders.forEach((s) => this.renderSlider(s));
          this.toggles.forEach((t) => this.renderToggle(t));
          this.applyLive();
          this.flash("PADRÕES RESTAURADOS");
        },
      },
      {
        label: "SAIR",
        run: () => {
          this.state = { ...this.saved };
          const nav = this.registry.get("navigate") as ((to: string) => void) | undefined;
          if (nav) nav("/");
        },
      },
    ];

    const w = 200;
    const spacing = 220;
    const startX = BASE_W / 2 - spacing;

    defs.forEach((def, i) => {
      const x = startX + i * spacing;
      const g = this.add.graphics().setDepth(6);
      const draw = (hover: boolean) => {
        g.clear();
        g.fillStyle(hover ? 0x2a2b33 : 0x1a1b21, 1).fillRoundedRect(x - w / 2, y - 20, w, 40, 5);
        g.lineStyle(3, hover ? 0xe0c25a : 0x767a86, 1).strokeRoundedRect(x - w / 2, y - 20, w, 40, 5);
        g.lineStyle(1, 0x0a0a0c, 1).strokeRoundedRect(x - w / 2 + 6, y - 14, w - 12, 28, 3);
      };
      draw(false);
      const label = this.add
        .text(x, y, def.label, {
          fontFamily: "monospace",
          fontSize: "19px",
          color: "#ddd0a6",
          fontStyle: "bold",
        })
        .setOrigin(0.5)
        .setDepth(7)
        .setShadow(0, 2, "#000000", 2);

      this.add
        .zone(x, y, w, 44)
        .setOrigin(0.5)
        .setInteractive({ useHandCursor: true })
        .on("pointerover", () => {
          draw(true);
          label.setColor("#ffeec0");
        })
        .on("pointerout", () => {
          draw(false);
          label.setColor("#ddd0a6");
        })
        .on("pointerdown", def.run);
    });
  }

  private flash(msg: string) {
    this.hint.setText(msg).setAlpha(1);
    this.tweens.add({ targets: this.hint, alpha: 0, duration: 1800, delay: 700 });
  }

  /* ------------------------------------------------------------- overlays */

  private buildOverlays() {
    this.bright = this.add.graphics().setDepth(48);
    this.contrast = this.add.graphics().setDepth(49);

    this.scan = this.add
      .tileSprite(0, 0, BASE_W, BASE_H, "scanline")
      .setOrigin(0)
      .setAlpha(0.16)
      .setDepth(50);

    this.hint = this.add
      .text(BASE_W / 2, 146, "", {
        fontFamily: "monospace",
        fontSize: "14px",
        color: "#e0b34a",
        fontStyle: "bold",
      })
      .setOrigin(0.5)
      .setAlpha(0)
      .setDepth(52);
  }

  /** Brightness/contrast/scanlines are previewed live on this very screen. */
  private applyLive() {
    const b = this.state.brightness - 0.5;
    this.bright.clear();
    if (b > 0) this.bright.fillStyle(0xfff0d0, b * 0.4).fillRect(0, 0, BASE_W, BASE_H);
    else if (b < 0) this.bright.fillStyle(0x000000, -b * 0.7).fillRect(0, 0, BASE_W, BASE_H);

    const c = this.state.contrast - 0.5;
    this.contrast.clear();
    if (c < 0) this.contrast.fillStyle(0x6a6a70, -c * 0.35).fillRect(0, 0, BASE_W, BASE_H);

    this.scan.setAlpha(this.state.scanlines ? 0.16 : 0);
  }

  private bindInput() {
    this.input.on("pointermove", (p: Phaser.Input.Pointer) => {
      if (this.dragging && p.isDown) this.setFromPointer(this.dragging, p.worldX);
    });
    const stop = () => {
      this.dragging = null;
    };
    this.input.on("pointerup", stop);
    this.input.on("pointerupoutside", stop);
  }

  /* ----------------------------------------------------------------- loop */

  override update(_time: number, delta: number) {
    this.t0 += delta / 1000;
    const t = this.t0;
    const n = (flicker(t, 1.7) + 1) / 2;

    this.plaqueGlow.setAlpha(0.12 + 0.08 * n + 0.04 * Math.sin(t * 1.6));
    this.logo.y = 62 + Math.sin(t * 1.1) * 2;

    const level = 0.55 + 0.45 * n;
    const tint = Phaser.Display.Color.GetColor(
      Math.round(150 + 70 * level),
      Math.round(142 + 62 * level),
      Math.round(132 + 46 * level),
    );
    this.lit.forEach((o) => o.setTint(tint));

    this.sliders.forEach((s, i) => {
      const p = (flicker(t * 0.8, i * 3.1 + 2) + 1) / 2;
      s.glow.setAlpha(0.32 + 0.22 * p);
      s.glow.setDisplaySize(104 + 22 * p, 104 + 22 * p);
    });
  }
}
